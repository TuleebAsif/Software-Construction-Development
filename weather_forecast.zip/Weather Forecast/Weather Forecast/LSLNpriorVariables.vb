﻿Module LSLNpriorVariables

    '''''''bayesian method''''''''

    ''rule: 1

    Public RainLS As Decimal = 2.5
    Public RainLN As Decimal = 0.6
    Public priorRain As Decimal = 0.5

    ''
    Public oddrain As Decimal
    Public oddrainrain As Decimal
    Public posteriorrainrain As Decimal

    ''rule: 2
    Public DryLS As Decimal = 1.6
    Public DryLN As Decimal = 0.4
    Public priorDry As Decimal = 0.5

    ''
    Public odddry As Decimal
    Public odddryrain As Decimal
    Public posteriordryrain As Decimal

    ''rule: 3
    Public RainfallLS As Decimal = 10
    Public RainfallLN As Decimal = 1

    ''
    Public odddryrainfall As Decimal
    Public odddryrainrainfall As Decimal
    Public posteriordryrainrainfall As Decimal

    ''rule: 4
    Public TempcoldLS As Decimal = 1.5
    Public TempcoldLN As Decimal = 1

    ''
    Public odddryTempcold As Decimal
    Public odddryrainrainfallTempcold As Decimal
    Public posteriordryrainrainfallTempcold As Decimal

    ''rule: 5
    Public TempwarmLS As Decimal = 2
    Public TempwarmLN As Decimal = 0.9

    ''
    Public oddrainTempwarm As Decimal
    Public oddrainnotdrynotwarm As Decimal
    Public posteriorrainnotdrynotwarm As Decimal

    ''rule: 6
    Public SkyLS As Decimal = 5
    Public SkyLN As Decimal = 1

    ''
    Public oddrainSky As Decimal
    Public oddrainnotdrynotwarmSky As Decimal
    Public posteriorrainnotdrynotwarmSky As Decimal

    ''''''''''''''''''''''''

    ''''''''''certainty factors'''''''''''

    '''''rain''''''

    ''rule: 1
    Public cftodaytomrain As Decimal = 0.5
    Public cftodayrain As Decimal = 1

    Public cftomraintodayrain As Decimal

    ''rule: 3
    Public cfrainfalltomdry As Decimal = 0.6
    Public cfnumericrainfalllow As Decimal  ''cfnumericrainfalllow=cmbnumericrainfalllow
    Public cftomdrytodayrainrainfalllow As Decimal
    Public mincftodayrainrainfalllow As Decimal

    ''rule: 4
    Public cfTemptomdry As Decimal = 0.7
    Public cfnumericTempcold As Decimal  ''cfnumericTempcold=cmbnumericTempcold
    Public cftomdrytodayrainrainfalllowTempcold As Decimal
    Public mincftodayrainrainfalllowTempcold As Decimal

    Public cfcfrule3cfrule4 As Decimal
    '''''''''''''''

    '''''''dry'''''

    ''rule: 2
    Public cftodaytomdry As Decimal = 0.5
    Public cftodaydry As Decimal = 1

    Public cftomdrytodaydry As Decimal


    ''rule: 5
    Public cfTemptomrain As Decimal = 0.65
    Public cfnumericTempwarm As Decimal  ''cfnumericrainfalllow=cmbnumericTempcoldwarm
    Public cftomraintodaydryTempcold As Decimal
    Public mincftodaydryTempcold As Decimal

    ''rule: 6

    Public cfSkytomrain As Decimal = 0.55
    Public cfnumericSkyovercast As Decimal  ''cfnumericSkyovercast=cmbnumericsky
    Public cftomraintodaydryTempcoldSkyovercast As Decimal
    Public mincftodaydryTempcoldSkyovercast As Decimal

    Public cfcfrule5cfrule6 As Decimal


    ''''''''''''''''''

    ''display conclusion''
    Public msgconclusiondryrain As String

    ''


End Module
