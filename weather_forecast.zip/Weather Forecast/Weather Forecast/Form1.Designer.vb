﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.tabforecastmenu = New System.Windows.Forms.TabPage
        Me.btntabmain = New System.Windows.Forms.Button
        Me.BCancel = New System.Windows.Forms.Button
        Me.Label5 = New System.Windows.Forms.Label
        Me.rdobcertainty = New System.Windows.Forms.RadioButton
        Me.rdobbayesian = New System.Windows.Forms.RadioButton
        Me.tabtoday = New System.Windows.Forms.TabPage
        Me.btntabforwardchain = New System.Windows.Forms.Button
        Me.Button13 = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.cmbtoday = New System.Windows.Forms.ComboBox
        Me.tabrainfall = New System.Windows.Forms.TabPage
        Me.lbllow2 = New System.Windows.Forms.Label
        Me.lbllow1 = New System.Windows.Forms.Label
        Me.cmbnumericrainfalllow = New System.Windows.Forms.ComboBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.cmbrainfall = New System.Windows.Forms.ComboBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.tabTemp = New System.Windows.Forms.TabPage
        Me.lblcold2 = New System.Windows.Forms.Label
        Me.lblcold1 = New System.Windows.Forms.Label
        Me.cmbnumericTempcoldwarm = New System.Windows.Forms.ComboBox
        Me.Button3 = New System.Windows.Forms.Button
        Me.Button4 = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.cmbTemp = New System.Windows.Forms.ComboBox
        Me.tabsky = New System.Windows.Forms.TabPage
        Me.lblsky2 = New System.Windows.Forms.Label
        Me.lblsky1 = New System.Windows.Forms.Label
        Me.cmbnumericsky = New System.Windows.Forms.ComboBox
        Me.Button5 = New System.Windows.Forms.Button
        Me.Button6 = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.cmbSky = New System.Windows.Forms.ComboBox
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ForecastAnnouncerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ShowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HideToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.Label6 = New System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.TabControl1.SuspendLayout()
        Me.tabforecastmenu.SuspendLayout()
        Me.tabtoday.SuspendLayout()
        Me.tabrainfall.SuspendLayout()
        Me.tabTemp.SuspendLayout()
        Me.tabsky.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.tabforecastmenu)
        Me.TabControl1.Controls.Add(Me.tabtoday)
        Me.TabControl1.Controls.Add(Me.tabrainfall)
        Me.TabControl1.Controls.Add(Me.tabTemp)
        Me.TabControl1.Controls.Add(Me.tabsky)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 24)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(476, 300)
        Me.TabControl1.TabIndex = 2
        '
        'tabforecastmenu
        '
        Me.tabforecastmenu.Controls.Add(Me.btntabmain)
        Me.tabforecastmenu.Controls.Add(Me.BCancel)
        Me.tabforecastmenu.Controls.Add(Me.Label5)
        Me.tabforecastmenu.Controls.Add(Me.rdobcertainty)
        Me.tabforecastmenu.Controls.Add(Me.rdobbayesian)
        Me.tabforecastmenu.Location = New System.Drawing.Point(4, 22)
        Me.tabforecastmenu.Name = "tabforecastmenu"
        Me.tabforecastmenu.Padding = New System.Windows.Forms.Padding(3)
        Me.tabforecastmenu.Size = New System.Drawing.Size(468, 274)
        Me.tabforecastmenu.TabIndex = 0
        Me.tabforecastmenu.Text = "tabforecastmenu"
        Me.tabforecastmenu.UseVisualStyleBackColor = True
        '
        'btntabmain
        '
        Me.btntabmain.BackColor = System.Drawing.SystemColors.Control
        Me.btntabmain.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btntabmain.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btntabmain.Font = New System.Drawing.Font("Candara", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btntabmain.Image = CType(resources.GetObject("btntabmain.Image"), System.Drawing.Image)
        Me.btntabmain.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btntabmain.Location = New System.Drawing.Point(286, 230)
        Me.btntabmain.Name = "btntabmain"
        Me.btntabmain.Size = New System.Drawing.Size(85, 37)
        Me.btntabmain.TabIndex = 31
        Me.btntabmain.Text = "&Ok:"
        Me.btntabmain.UseVisualStyleBackColor = False
        '
        'BCancel
        '
        Me.BCancel.BackColor = System.Drawing.SystemColors.Control
        Me.BCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BCancel.Font = New System.Drawing.Font("Candara", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BCancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BCancel.Image = CType(resources.GetObject("BCancel.Image"), System.Drawing.Image)
        Me.BCancel.Location = New System.Drawing.Point(379, 230)
        Me.BCancel.Name = "BCancel"
        Me.BCancel.Size = New System.Drawing.Size(85, 37)
        Me.BCancel.TabIndex = 32
        Me.BCancel.Text = "&Cancel:"
        Me.BCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BCancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BCancel.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(8, 29)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(312, 20)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "What FORECAST method you prefer?"
        '
        'rdobcertainty
        '
        Me.rdobcertainty.AutoSize = True
        Me.rdobcertainty.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdobcertainty.Location = New System.Drawing.Point(59, 130)
        Me.rdobcertainty.Name = "rdobcertainty"
        Me.rdobcertainty.Size = New System.Drawing.Size(357, 24)
        Me.rdobcertainty.TabIndex = 1
        Me.rdobcertainty.Text = "AN APPLICATION OF CERTAINTY FACTORS"
        Me.rdobcertainty.UseVisualStyleBackColor = True
        '
        'rdobbayesian
        '
        Me.rdobbayesian.AutoSize = True
        Me.rdobbayesian.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdobbayesian.Location = New System.Drawing.Point(59, 90)
        Me.rdobbayesian.Name = "rdobbayesian"
        Me.rdobbayesian.Size = New System.Drawing.Size(353, 24)
        Me.rdobbayesian.TabIndex = 0
        Me.rdobbayesian.Text = "BAYESIAN ACCUMULATION OF EVIDENCE"
        Me.rdobbayesian.UseVisualStyleBackColor = True
        '
        'tabtoday
        '
        Me.tabtoday.Controls.Add(Me.btntabforwardchain)
        Me.tabtoday.Controls.Add(Me.Button13)
        Me.tabtoday.Controls.Add(Me.Label1)
        Me.tabtoday.Controls.Add(Me.cmbtoday)
        Me.tabtoday.Location = New System.Drawing.Point(4, 22)
        Me.tabtoday.Name = "tabtoday"
        Me.tabtoday.Padding = New System.Windows.Forms.Padding(3)
        Me.tabtoday.Size = New System.Drawing.Size(468, 274)
        Me.tabtoday.TabIndex = 1
        Me.tabtoday.Text = "tabtoday"
        Me.tabtoday.UseVisualStyleBackColor = True
        '
        'btntabforwardchain
        '
        Me.btntabforwardchain.BackColor = System.Drawing.SystemColors.Control
        Me.btntabforwardchain.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btntabforwardchain.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btntabforwardchain.Font = New System.Drawing.Font("Candara", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btntabforwardchain.Image = CType(resources.GetObject("btntabforwardchain.Image"), System.Drawing.Image)
        Me.btntabforwardchain.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btntabforwardchain.Location = New System.Drawing.Point(375, 229)
        Me.btntabforwardchain.Name = "btntabforwardchain"
        Me.btntabforwardchain.Size = New System.Drawing.Size(85, 37)
        Me.btntabforwardchain.TabIndex = 33
        Me.btntabforwardchain.Text = "&Ok:"
        Me.btntabforwardchain.UseVisualStyleBackColor = False
        '
        'Button13
        '
        Me.Button13.BackColor = System.Drawing.SystemColors.Control
        Me.Button13.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button13.Font = New System.Drawing.Font("Candara", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button13.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button13.Image = CType(resources.GetObject("Button13.Image"), System.Drawing.Image)
        Me.Button13.Location = New System.Drawing.Point(282, 229)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(85, 37)
        Me.Button13.TabIndex = 34
        Me.Button13.Text = "&Back:"
        Me.Button13.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button13.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(8, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(228, 20)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "What is the weather today?"
        '
        'cmbtoday
        '
        Me.cmbtoday.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbtoday.FormattingEnabled = True
        Me.cmbtoday.Items.AddRange(New Object() {"Rain", "Dry"})
        Me.cmbtoday.Location = New System.Drawing.Point(102, 47)
        Me.cmbtoday.Name = "cmbtoday"
        Me.cmbtoday.Size = New System.Drawing.Size(134, 28)
        Me.cmbtoday.TabIndex = 2
        '
        'tabrainfall
        '
        Me.tabrainfall.Controls.Add(Me.lbllow2)
        Me.tabrainfall.Controls.Add(Me.lbllow1)
        Me.tabrainfall.Controls.Add(Me.cmbnumericrainfalllow)
        Me.tabrainfall.Controls.Add(Me.Label2)
        Me.tabrainfall.Controls.Add(Me.cmbrainfall)
        Me.tabrainfall.Controls.Add(Me.Button1)
        Me.tabrainfall.Controls.Add(Me.Button2)
        Me.tabrainfall.Location = New System.Drawing.Point(4, 22)
        Me.tabrainfall.Name = "tabrainfall"
        Me.tabrainfall.Padding = New System.Windows.Forms.Padding(3)
        Me.tabrainfall.Size = New System.Drawing.Size(468, 274)
        Me.tabrainfall.TabIndex = 2
        Me.tabrainfall.Text = "tabrainfall"
        Me.tabrainfall.UseVisualStyleBackColor = True
        '
        'lbllow2
        '
        Me.lbllow2.AutoSize = True
        Me.lbllow2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbllow2.Location = New System.Drawing.Point(36, 131)
        Me.lbllow2.Name = "lbllow2"
        Me.lbllow2.Size = New System.Drawing.Size(134, 15)
        Me.lbllow2.TabIndex = 39
        Me.lbllow2.Text = "bet. 0 and 1.0 inclusive."
        Me.lbllow2.Visible = False
        '
        'lbllow1
        '
        Me.lbllow1.AutoSize = True
        Me.lbllow1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbllow1.Location = New System.Drawing.Point(36, 109)
        Me.lbllow1.Name = "lbllow1"
        Me.lbllow1.Size = New System.Drawing.Size(415, 15)
        Me.lbllow1.TabIndex = 38
        Me.lbllow1.Text = "To what degree do you believe the rainfall is low? Enter a numeric certainty "
        Me.lbllow1.Visible = False
        '
        'cmbnumericrainfalllow
        '
        Me.cmbnumericrainfalllow.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbnumericrainfalllow.FormattingEnabled = True
        Me.cmbnumericrainfalllow.Items.AddRange(New Object() {"0.1", "0.2", "0.3", "0.4", "0.5", "0.6", "0.7", "0.8", "0.9", "1.0"})
        Me.cmbnumericrainfalllow.Location = New System.Drawing.Point(149, 161)
        Me.cmbnumericrainfalllow.Name = "cmbnumericrainfalllow"
        Me.cmbnumericrainfalllow.Size = New System.Drawing.Size(54, 23)
        Me.cmbnumericrainfalllow.TabIndex = 37
        Me.cmbnumericrainfalllow.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(8, 13)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(218, 20)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "What is the rainfall today?"
        '
        'cmbrainfall
        '
        Me.cmbrainfall.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbrainfall.FormattingEnabled = True
        Me.cmbrainfall.Items.AddRange(New Object() {"Low"})
        Me.cmbrainfall.Location = New System.Drawing.Point(105, 40)
        Me.cmbrainfall.Name = "cmbrainfall"
        Me.cmbrainfall.Size = New System.Drawing.Size(121, 28)
        Me.cmbrainfall.TabIndex = 4
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.Control
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button1.Font = New System.Drawing.Font("Candara", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.Location = New System.Drawing.Point(375, 229)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(85, 37)
        Me.Button1.TabIndex = 35
        Me.Button1.Text = "&Ok:"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.SystemColors.Control
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.Font = New System.Drawing.Font("Candara", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button2.Image = CType(resources.GetObject("Button2.Image"), System.Drawing.Image)
        Me.Button2.Location = New System.Drawing.Point(282, 229)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(85, 37)
        Me.Button2.TabIndex = 36
        Me.Button2.Text = "&Back:"
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button2.UseVisualStyleBackColor = True
        '
        'tabTemp
        '
        Me.tabTemp.Controls.Add(Me.lblcold2)
        Me.tabTemp.Controls.Add(Me.lblcold1)
        Me.tabTemp.Controls.Add(Me.cmbnumericTempcoldwarm)
        Me.tabTemp.Controls.Add(Me.Button3)
        Me.tabTemp.Controls.Add(Me.Button4)
        Me.tabTemp.Controls.Add(Me.Label3)
        Me.tabTemp.Controls.Add(Me.cmbTemp)
        Me.tabTemp.Location = New System.Drawing.Point(4, 22)
        Me.tabTemp.Name = "tabTemp"
        Me.tabTemp.Padding = New System.Windows.Forms.Padding(3)
        Me.tabTemp.Size = New System.Drawing.Size(468, 274)
        Me.tabTemp.TabIndex = 3
        Me.tabTemp.Text = "tabTemp"
        Me.tabTemp.UseVisualStyleBackColor = True
        '
        'lblcold2
        '
        Me.lblcold2.AutoSize = True
        Me.lblcold2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcold2.Location = New System.Drawing.Point(13, 132)
        Me.lblcold2.Name = "lblcold2"
        Me.lblcold2.Size = New System.Drawing.Size(134, 15)
        Me.lblcold2.TabIndex = 42
        Me.lblcold2.Text = "bet. 0 and 1.0 inclusive."
        Me.lblcold2.Visible = False
        '
        'lblcold1
        '
        Me.lblcold1.AutoSize = True
        Me.lblcold1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcold1.Location = New System.Drawing.Point(13, 110)
        Me.lblcold1.Name = "lblcold1"
        Me.lblcold1.Size = New System.Drawing.Size(449, 15)
        Me.lblcold1.TabIndex = 41
        Me.lblcold1.Text = "To what degree do you believe the temperature is cold? Enter a numeric certainty " & _
            ""
        Me.lblcold1.Visible = False
        '
        'cmbnumericTempcoldwarm
        '
        Me.cmbnumericTempcoldwarm.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbnumericTempcoldwarm.FormattingEnabled = True
        Me.cmbnumericTempcoldwarm.Items.AddRange(New Object() {"0.1", "0.2", "0.3", "0.4", "0.5", "0.6", "0.7", "0.8", "0.9", "1.0"})
        Me.cmbnumericTempcoldwarm.Location = New System.Drawing.Point(138, 159)
        Me.cmbnumericTempcoldwarm.Name = "cmbnumericTempcoldwarm"
        Me.cmbnumericTempcoldwarm.Size = New System.Drawing.Size(54, 23)
        Me.cmbnumericTempcoldwarm.TabIndex = 40
        Me.cmbnumericTempcoldwarm.Visible = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.SystemColors.Control
        Me.Button3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button3.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button3.Font = New System.Drawing.Font("Candara", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Image = CType(resources.GetObject("Button3.Image"), System.Drawing.Image)
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button3.Location = New System.Drawing.Point(375, 229)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(85, 37)
        Me.Button3.TabIndex = 37
        Me.Button3.Text = "&Ok:"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.SystemColors.Control
        Me.Button4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button4.Font = New System.Drawing.Font("Candara", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button4.Image = CType(resources.GetObject("Button4.Image"), System.Drawing.Image)
        Me.Button4.Location = New System.Drawing.Point(282, 229)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(85, 37)
        Me.Button4.TabIndex = 38
        Me.Button4.Text = "&Back:"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(8, 14)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(262, 20)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "What is the temperature today?"
        '
        'cmbTemp
        '
        Me.cmbTemp.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbTemp.FormattingEnabled = True
        Me.cmbTemp.Items.AddRange(New Object() {"Cold", "Warm"})
        Me.cmbTemp.Location = New System.Drawing.Point(138, 46)
        Me.cmbTemp.Name = "cmbTemp"
        Me.cmbTemp.Size = New System.Drawing.Size(121, 28)
        Me.cmbTemp.TabIndex = 6
        '
        'tabsky
        '
        Me.tabsky.Controls.Add(Me.lblsky2)
        Me.tabsky.Controls.Add(Me.lblsky1)
        Me.tabsky.Controls.Add(Me.cmbnumericsky)
        Me.tabsky.Controls.Add(Me.Button5)
        Me.tabsky.Controls.Add(Me.Button6)
        Me.tabsky.Controls.Add(Me.Label4)
        Me.tabsky.Controls.Add(Me.cmbSky)
        Me.tabsky.Location = New System.Drawing.Point(4, 22)
        Me.tabsky.Name = "tabsky"
        Me.tabsky.Padding = New System.Windows.Forms.Padding(3)
        Me.tabsky.Size = New System.Drawing.Size(468, 274)
        Me.tabsky.TabIndex = 4
        Me.tabsky.Text = "tabsky"
        Me.tabsky.UseVisualStyleBackColor = True
        '
        'lblsky2
        '
        Me.lblsky2.AutoSize = True
        Me.lblsky2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblsky2.Location = New System.Drawing.Point(13, 125)
        Me.lblsky2.Name = "lblsky2"
        Me.lblsky2.Size = New System.Drawing.Size(134, 15)
        Me.lblsky2.TabIndex = 45
        Me.lblsky2.Text = "bet. 0 and 1.0 inclusive."
        Me.lblsky2.Visible = False
        '
        'lblsky1
        '
        Me.lblsky1.AutoSize = True
        Me.lblsky1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblsky1.Location = New System.Drawing.Point(13, 103)
        Me.lblsky1.Name = "lblsky1"
        Me.lblsky1.Size = New System.Drawing.Size(421, 15)
        Me.lblsky1.TabIndex = 44
        Me.lblsky1.Text = "To what degree do you believe the sky is overcast? Enter a numeric certainty "
        Me.lblsky1.Visible = False
        '
        'cmbnumericsky
        '
        Me.cmbnumericsky.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbnumericsky.FormattingEnabled = True
        Me.cmbnumericsky.Items.AddRange(New Object() {"0.1", "0.2", "0.3", "0.4", "0.5", "0.6", "0.7", "0.8", "0.9", "1.0"})
        Me.cmbnumericsky.Location = New System.Drawing.Point(138, 152)
        Me.cmbnumericsky.Name = "cmbnumericsky"
        Me.cmbnumericsky.Size = New System.Drawing.Size(54, 23)
        Me.cmbnumericsky.TabIndex = 43
        Me.cmbnumericsky.Visible = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.SystemColors.Control
        Me.Button5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button5.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button5.Font = New System.Drawing.Font("Candara", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Image = CType(resources.GetObject("Button5.Image"), System.Drawing.Image)
        Me.Button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button5.Location = New System.Drawing.Point(375, 229)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(85, 37)
        Me.Button5.TabIndex = 39
        Me.Button5.Text = "&Ok:"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.SystemColors.Control
        Me.Button6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button6.Font = New System.Drawing.Font("Candara", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button6.Image = CType(resources.GetObject("Button6.Image"), System.Drawing.Image)
        Me.Button6.Location = New System.Drawing.Point(282, 229)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(85, 37)
        Me.Button6.TabIndex = 40
        Me.Button6.Text = "&Back:"
        Me.Button6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(8, 13)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(255, 20)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "What is the cloud cover today?"
        '
        'cmbSky
        '
        Me.cmbSky.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbSky.FormattingEnabled = True
        Me.cmbSky.Items.AddRange(New Object() {"Overcast"})
        Me.cmbSky.Location = New System.Drawing.Point(132, 49)
        Me.cmbSky.Name = "cmbSky"
        Me.cmbSky.Size = New System.Drawing.Size(121, 28)
        Me.cmbSky.TabIndex = 8
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.SettingsToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(476, 24)
        Me.MenuStrip1.TabIndex = 3
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Image = Global.Weather_Forecast.My.Resources.Resources.file
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(53, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Image = Global.Weather_Forecast.My.Resources.Resources.app_delete
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'SettingsToolStripMenuItem
        '
        Me.SettingsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ForecastAnnouncerToolStripMenuItem})
        Me.SettingsToolStripMenuItem.Image = Global.Weather_Forecast.My.Resources.Resources.gear_64
        Me.SettingsToolStripMenuItem.Name = "SettingsToolStripMenuItem"
        Me.SettingsToolStripMenuItem.Size = New System.Drawing.Size(77, 20)
        Me.SettingsToolStripMenuItem.Text = "Settings"
        '
        'ForecastAnnouncerToolStripMenuItem
        '
        Me.ForecastAnnouncerToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShowToolStripMenuItem, Me.HideToolStripMenuItem})
        Me.ForecastAnnouncerToolStripMenuItem.Image = Global.Weather_Forecast.My.Resources.Resources.video_professionals_leader
        Me.ForecastAnnouncerToolStripMenuItem.Name = "ForecastAnnouncerToolStripMenuItem"
        Me.ForecastAnnouncerToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ForecastAnnouncerToolStripMenuItem.Text = "Forecast Announcer"
        '
        'ShowToolStripMenuItem
        '
        Me.ShowToolStripMenuItem.Name = "ShowToolStripMenuItem"
        Me.ShowToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ShowToolStripMenuItem.Text = "Show"
        '
        'HideToolStripMenuItem
        '
        Me.HideToolStripMenuItem.Name = "HideToolStripMenuItem"
        Me.HideToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.HideToolStripMenuItem.Text = "Hide"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(122, 25)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(218, 18)
        Me.Label6.TabIndex = 34
        Me.Label6.Text = "Knowledge-base Expert System"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.PictureBox1.Location = New System.Drawing.Point(0, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(476, 21)
        Me.PictureBox1.TabIndex = 33
        Me.PictureBox1.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(476, 324)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Simple Weather Forecast v1.1"
        Me.TabControl1.ResumeLayout(False)
        Me.tabforecastmenu.ResumeLayout(False)
        Me.tabforecastmenu.PerformLayout()
        Me.tabtoday.ResumeLayout(False)
        Me.tabtoday.PerformLayout()
        Me.tabrainfall.ResumeLayout(False)
        Me.tabrainfall.PerformLayout()
        Me.tabTemp.ResumeLayout(False)
        Me.tabTemp.PerformLayout()
        Me.tabsky.ResumeLayout(False)
        Me.tabsky.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tabforecastmenu As System.Windows.Forms.TabPage
    Friend WithEvents tabtoday As System.Windows.Forms.TabPage
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmbtoday As System.Windows.Forms.ComboBox
    Friend WithEvents tabrainfall As System.Windows.Forms.TabPage
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmbrainfall As System.Windows.Forms.ComboBox
    Friend WithEvents tabTemp As System.Windows.Forms.TabPage
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cmbTemp As System.Windows.Forms.ComboBox
    Friend WithEvents tabsky As System.Windows.Forms.TabPage
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cmbSky As System.Windows.Forms.ComboBox
    Friend WithEvents rdobcertainty As System.Windows.Forms.RadioButton
    Friend WithEvents rdobbayesian As System.Windows.Forms.RadioButton
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btntabmain As System.Windows.Forms.Button
    Friend WithEvents BCancel As System.Windows.Forms.Button
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btntabforwardchain As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents lbllow1 As System.Windows.Forms.Label
    Friend WithEvents cmbnumericrainfalllow As System.Windows.Forms.ComboBox
    Friend WithEvents lbllow2 As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents SettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ForecastAnnouncerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ShowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HideToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents lblcold2 As System.Windows.Forms.Label
    Friend WithEvents lblcold1 As System.Windows.Forms.Label
    Friend WithEvents cmbnumericTempcoldwarm As System.Windows.Forms.ComboBox
    Friend WithEvents lblsky2 As System.Windows.Forms.Label
    Friend WithEvents lblsky1 As System.Windows.Forms.Label
    Friend WithEvents cmbnumericsky As System.Windows.Forms.ComboBox

End Class
