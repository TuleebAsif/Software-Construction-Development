﻿Public Class Form1


    Private Sub btntabmain_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btntabmain.Click

        My.Computer.Audio.Play(My.Resources.weathertoday, AudioPlayMode.Background)


        If rdobbayesian.Checked = True Then
            ''show bayesian method
            TabControl1.SelectTab(tabtoday)

        ElseIf rdobcertainty.Checked = True Then

            ''show certainty factor
            TabControl1.SelectTab(tabtoday)



        End If
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()

    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim response As MsgBoxResult
        response = MsgBox("Do you want to exit?", _
                          vbYesNo + vbExclamation + vbApplicationModal + _
                          vbDefaultButton2, "Simple Weather Forecast v1.1")
        If response = MsgBoxResult.Yes Then
            Me.Visible = False
            Me.Dispose()
            Me.Close()
            End
        ElseIf response = MsgBoxResult.No Then
            e.Cancel = True
            Exit Sub
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ''audio
        My.Computer.Audio.Play(My.Resources.whatmethod, AudioPlayMode.Background)
        frmvirtual.Show()
       
      
        Dim x As Integer
        Dim y As Integer
        x = Screen.PrimaryScreen.WorkingArea.Width
        y = Screen.PrimaryScreen.WorkingArea.Height - frmvirtual.Height

        Do Until x = Screen.PrimaryScreen.WorkingArea.Width - frmvirtual.Width
            x = x - 1
            frmvirtual.Location = New Point(x, y)
        Loop

    End Sub

    Private Sub BCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BCancel.Click
        Me.Close()

    End Sub

    Private Sub btntabforwardchain_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btntabforwardchain.Click


        ''if bayesian mechod=true
        If rdobbayesian.Checked = True Then

            ''hide lbllow1, lbllow2, cmblow

            lbllow1.Visible = False
            lbllow2.Visible = False
            cmbnumericrainfalllow.Visible = False


            ''if today=rain
            If cmbtoday.Text = "Rain" Then

              
                'rule 1'''''''''''''''
                oddrain = priorRain / (1 - priorRain)
                oddrainrain = RainLS * oddrain
                posteriorrainrain = oddrainrain / (1 + oddrainrain)

                'rule 2''''''odd dry''''
                odddry = priorDry / (1 - priorDry)
                odddryrain = DryLN * odddry
                posteriordryrain = odddryrain / (1 + odddryrain)
                ''''''''''''''''

                MsgBox("Tomorrow is rain " + posteriorrainrain.ToString("N") + "dry " + posteriordryrain.ToString("N"))


                TabControl1.SelectTab(tabrainfall)


                ''audio

                My.Computer.Audio.Play(My.Resources.rainfalltoday, AudioPlayMode.Background)

                ''if today=dry
            ElseIf cmbtoday.Text = "Dry" Then

              

                'rule 1''''''odd rain''''''''
                oddrain = priorRain / (1 - priorRain)


                oddrainrain = RainLN * oddrain
                posteriorrainrain = oddrainrain / (1 + oddrainrain)
                '''''''''''''''

                'rule 2'''''''
                odddry = priorDry / (1 - priorDry)
                odddryrain = DryLS * odddry
                posteriordryrain = odddryrain / (1 + odddryrain)

                MsgBox("Tomorrow is rain " + posteriorrainrain.ToString("N") + " dry " + posteriordryrain.ToString("N"))

                TabControl1.SelectTab(tabTemp)


                ''audio

                My.Computer.Audio.Play(My.Resources.Temptoday, AudioPlayMode.Background)

            End If



            ''if certainty factors=true
        ElseIf rdobcertainty.Checked = True Then

          
            ''if today=rain
            If cmbtoday.Text = "Rain" Then

                cftomraintodayrain = cftodayrain * cftodaytomrain

                MsgBox("Tomorrow is rain " + cftomraintodayrain.ToString("N"))

                TabControl1.SelectTab(tabrainfall)


                ''audio

                My.Computer.Audio.Play(My.Resources.rainfalltoday, AudioPlayMode.Background)

                ''if today=dry
            ElseIf cmbtoday.Text = "Dry" Then


                cftomdrytodaydry = cftodaydry * cftodaytomdry

                MsgBox("Tomorrow is dry " + cftomdrytodaydry.ToString("N"))

                TabControl1.SelectTab(tabTemp)


                ''audio

                My.Computer.Audio.Play(My.Resources.Temptoday, AudioPlayMode.Background)


            End If





        End If

    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        ''if bayesian mechod=true
        If rdobbayesian.Checked = True Then


            ''hide lblcold1, lblcold2, cmbnumricTempcold

            lblcold1.Visible = False
            lblcold2.Visible = False
            cmbnumericTempcoldwarm.Visible = False


            ''if today=rain and rainfall=low
            If cmbtoday.Text = "Rain" And cmbrainfall.Text = "Low" Then

                odddryrainfall = posteriordryrain / (1 - posteriordryrain)
                odddryrainrainfall = RainfallLS * odddryrainfall
                posteriordryrainrainfall = odddryrainrainfall / (1 + odddryrainrainfall)

                MsgBox("Tomorrow is dry " + posteriordryrainrainfall.ToString("N") + " rain " + posteriorrainrain.ToString("N"))

                TabControl1.SelectTab(tabTemp)

                ''audio
                My.Computer.Audio.Play(My.Resources.Temptoday, AudioPlayMode.Background)

            Else


            End If



            ''if certainty factors=true
        ElseIf rdobcertainty.Checked = True Then


        


            ''if today=rain and rainfall=low
            If cmbtoday.Text = "Rain" And cmbrainfall.Text = "Low" Then

                cfnumericrainfalllow = cmbnumericrainfalllow.Text
                ''find the minimum
                If cftodayrain < cfnumericrainfalllow Then

                    mincftodayrainrainfalllow = cftodayrain

                Else

                    mincftodayrainrainfalllow = cfnumericrainfalllow

                End If


                cftomdrytodayrainrainfalllow = mincftodayrainrainfalllow * cfrainfalltomdry
                MsgBox("Tomorrow is rain " + cftomraintodayrain.ToString("N") + " dry " + cftomdrytodayrainrainfalllow.ToString("N"))

                TabControl1.SelectTab(tabTemp)


                ''audio
                My.Computer.Audio.Play(My.Resources.Temptoday, AudioPlayMode.Background)



            End If



        End If

    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        TabControl1.SelectTab(tabforecastmenu)
        ''audio
        My.Computer.Audio.Play(My.Resources.whatmethod, AudioPlayMode.Background)

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click


        My.Computer.Audio.Play(My.Resources.weathertoday, AudioPlayMode.Background)

        If rdobbayesian.Checked = True Then
            ''show bayesian method
            TabControl1.SelectTab(tabtoday)

        ElseIf rdobcertainty.Checked = True Then

            ''show certainty factor
            TabControl1.SelectTab(tabtoday)



        End If

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        TabControl1.SelectTab(tabrainfall)
        ''auio
        My.Computer.Audio.Play(My.Resources.rainfalltoday, AudioPlayMode.Background)

        If rdobbayesian.Checked = True Then
            ''show bayesian method
            TabControl1.SelectTab(tabrainfall)

        ElseIf rdobcertainty.Checked = True Then

            ''show certainty factor
            TabControl1.SelectTab(tabrainfall)



        End If


    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        TabControl1.SelectTab(tabTemp)
        ''audio

        My.Computer.Audio.Play(My.Resources.Temptoday, AudioPlayMode.Background)

    End Sub

    Private Sub ShowToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ShowToolStripMenuItem.Click
        frmvirtual.Show()
       
        Dim x As Integer
        Dim y As Integer
        x = Screen.PrimaryScreen.WorkingArea.Width
        y = Screen.PrimaryScreen.WorkingArea.Height - frmvirtual.Height

        Do Until x = Screen.PrimaryScreen.WorkingArea.Width - frmvirtual.Width
            x = x - 1
            frmvirtual.Location = New Point(x, y)
        Loop
    End Sub

    Private Sub HideToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HideToolStripMenuItem.Click
        frmvirtual.Close()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click


        ''if bayesian mechod=true
        If rdobbayesian.Checked = True Then


            ''if today=rain and rainfall=low and Temp=cold
            If cmbtoday.Text = "Rain" And cmbrainfall.Text = "Low" And cmbTemp.Text = "Cold" Then

                odddryTempcold = posteriordryrainrainfall / (1 - posteriordryrainrainfall)
                odddryrainrainfallTempcold = TempcoldLS * odddryTempcold
                posteriordryrainrainfallTempcold = odddryrainrainfallTempcold / (1 + odddryrainrainfallTempcold)


                ''rule 5''


                oddrainTempwarm = posteriorrainrain / (1 - posteriorrainrain)
                oddrainnotdrynotwarm = TempwarmLN * oddrainTempwarm
                posteriorrainnotdrynotwarm = oddrainnotdrynotwarm / (1 + oddrainnotdrynotwarm)

                ''

                MsgBox("Tomorrow is dry " + posteriordryrainrainfallTempcold.ToString("N") + " rain " + posteriorrainnotdrynotwarm.ToString("N"))

                TabControl1.SelectTab(tabforecastmenu)
                My.Computer.Audio.Play(My.Resources.whatmethod, AudioPlayMode.Background)


                ''if today=dry and Temp=warm
            ElseIf cmbtoday.Text = "Dry" And cmbTemp.Text = "Warm" Then



                ''''''
                odddryrainfall = posteriordryrain / (1 - posteriordryrain)
                odddryrainrainfall = RainfallLS * odddryrainfall
                posteriordryrainrainfall = odddryrainrainfall / (1 + odddryrainrainfall)

                '''''''
                '''''odd cold
                odddryTempcold = posteriordryrainrainfall / (1 - posteriordryrainrainfall)

                odddryrainrainfallTempcold = TempcoldLS * odddryTempcold
                posteriordryrainrainfallTempcold = odddryrainrainfallTempcold / (1 + odddryrainrainfallTempcold)
                ''''''

                oddrainTempwarm = posteriorrainrain / (1 - posteriorrainrain)
                oddrainnotdrynotwarm = TempwarmLN * oddrainTempwarm
                posteriorrainnotdrynotwarm = oddrainnotdrynotwarm / (1 + oddrainnotdrynotwarm)

                MsgBox("Tomorrow is dry " + posteriordryrainrainfallTempcold.ToString("N") + " rain " + posteriorrainnotdrynotwarm.ToString("N"))

                TabControl1.SelectTab(tabsky)



                ''audio
                My.Computer.Audio.Play(My.Resources.cloudcovertoday, AudioPlayMode.Background)

            End If





            ''if certainty factors=true
        ElseIf rdobcertainty.Checked = True Then



            ''if today=rain and rainfall=low and Temp=cold
            If cmbtoday.Text = "Rain" And cmbrainfall.Text = "Low" And cmbTemp.Text = "Cold" Then

                cfnumericTempcold = cmbnumericTempcoldwarm.Text

                ''find the minimum

                If cftodayrain < cfnumericrainfalllow And cftodayrain < cfnumericTempcold Then

                    mincftodayrainrainfalllowTempcold = cftodayrain

                ElseIf cfnumericrainfalllow < cftodayrain And cfnumericrainfalllow < cfnumericTempcold Then

                    mincftodayrainrainfalllowTempcold = cfnumericrainfalllow

                ElseIf cfnumericTempcold < cfnumericrainfalllow And cfnumericTempcold < cftodayrain Then

                    mincftodayrainrainfalllowTempcold = cfnumericTempcold

                End If


                cftomdrytodayrainrainfalllowTempcold = mincftodayrainrainfalllowTempcold * cfTemptomdry

                cfcfrule3cfrule4 = cftomdrytodayrainrainfalllow + cftomdrytodayrainrainfalllowTempcold * (1 - cftomdrytodayrainrainfalllow)



                MsgBox("Tomorrow is dry " + cftomdrytodayrainrainfalllowTempcold.ToString("N") + " rain " + cftomraintodayrain.ToString("N"))
                MsgBox("Tomorrow is dry " + cfcfrule3cfrule4.ToString("N") + " rain " + cftomraintodayrain.ToString("N"))

                '' display conclusion


                If cfcfrule3cfrule4 <= -1 Then

                    msgconclusiondryrain = "definitely not"

                ElseIf cfcfrule3cfrule4 > -1 And cfcfrule3cfrule4 <= -0.8 Then

                    msgconclusiondryrain = "almost certainly not"

                ElseIf cfcfrule3cfrule4 > -0.8 And cfcfrule3cfrule4 <= -0.6 Then

                    msgconclusiondryrain = "probably not"

                ElseIf cfcfrule3cfrule4 > -0.6 And cfcfrule3cfrule4 <= -0.4 Then

                    msgconclusiondryrain = "maybe not"

                ElseIf cfcfrule3cfrule4 > -0.4 And cfcfrule3cfrule4 <= 0.2 Then

                    msgconclusiondryrain = "unknown"

                ElseIf cfcfrule3cfrule4 > 0.2 And cfcfrule3cfrule4 <= 0.4 Then

                    msgconclusiondryrain = "maybe"

                ElseIf cfcfrule3cfrule4 > 0.4 And cfcfrule3cfrule4 <= 0.6 Then

                    msgconclusiondryrain = "probably"

                ElseIf cfcfrule3cfrule4 > 0.6 And cfcfrule3cfrule4 < 1.0 Then


                    msgconclusiondryrain = "almost certain"

                ElseIf cfcfrule3cfrule4 >= 1.0 Then

                    msgconclusiondryrain = "definitely"

                End If

                MsgBox("The probability of having a dry day tomorrow is " + msgconclusiondryrain.ToString + "; however we also may expect some rain!")


                TabControl1.SelectTab(tabforecastmenu)
                My.Computer.Audio.Play(My.Resources.whatmethod, AudioPlayMode.Background)





            Else



                ''if today=dry and temperature=warm
                If cmbtoday.Text = "Dry" And cmbTemp.Text = "Warm" Then

                    cfnumericTempwarm = cmbnumericTempcoldwarm.Text
                    ''find the minimum
                    If cftodaydry < cfnumericTempwarm Then

                        mincftodaydryTempcold = cftodaydry

                    Else

                        mincftodaydryTempcold = cfnumericTempwarm
                    End If


                    cftomraintodaydryTempcold = mincftodaydryTempcold * cfTemptomrain

                    MsgBox("Tomorrow is rain " + cftomraintodaydryTempcold.ToString("N") + " dry " + cftomdrytodaydry.ToString("N"))

                    TabControl1.SelectTab(tabsky)


                    ''audio
                    My.Computer.Audio.Play(My.Resources.cloudcovertoday, AudioPlayMode.Background)



                End If





            End If



        End If


    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click

        ''if bayesian mechod=true
        If rdobbayesian.Checked = True Then


            ''if today=dry and Temp=warm and Sky=Overcast

            If cmbtoday.Text = "Dry" And cmbTemp.Text = "Warm" And cmbSky.Text = "Overcast" Then


                oddrainSky = posteriorrainnotdrynotwarm / (1 - posteriorrainnotdrynotwarm)
                oddrainnotdrynotwarmSky = SkyLN * oddrainSky
                posteriorrainnotdrynotwarmSky = oddrainnotdrynotwarmSky / (1 + oddrainnotdrynotwarmSky)

                MsgBox("Tomorrow is dry " + posteriordryrainrainfallTempcold.ToString("N") + " rain " + posteriorrainnotdrynotwarmSky.ToString("N"))



            End If






            ''if certainty factors=true
        ElseIf rdobcertainty.Checked = True Then



            ''if today=dry and Temp=warm and sky=overcast
            If cmbtoday.Text = "Dry" And cmbTemp.Text = "Warm" And cmbSky.Text = "Overcast" Then

                cfnumericSkyovercast = cmbnumericsky.Text

                ''find the minimum
                If cftodaydry < cfnumericTempwarm And cftodaydry < cfnumericSkyovercast Then

                    mincftodaydryTempcoldSkyovercast = cftodaydry

                ElseIf cfnumericTempwarm < cftodaydry And cfnumericTempwarm < cfnumericSkyovercast Then

                    mincftodaydryTempcoldSkyovercast = cfnumericTempwarm

                ElseIf cfnumericSkyovercast < cfnumericTempwarm And cfnumericSkyovercast < cftodaydry Then

                    mincftodaydryTempcoldSkyovercast = cfnumericSkyovercast

                End If

                cftomraintodaydryTempcoldSkyovercast = mincftodaydryTempcoldSkyovercast * cfSkytomrain

                cfcfrule5cfrule6 = cftomraintodaydryTempcold + cftomraintodaydryTempcoldSkyovercast * (1 - cftomraintodaydryTempcold)



                MsgBox("Tomorrow is rain " + cftomraintodaydryTempcoldSkyovercast.ToString("N") + " dry " + cftomdrytodaydry.ToString("N"))
                MsgBox("Tomorrow is rain " + cfcfrule5cfrule6.ToString("N") + " dry " + cftomdrytodaydry.ToString("N"))


                '' display conclusion


                If cfcfrule5cfrule6 <= -1 Then

                    msgconclusiondryrain = "definitely not"

                ElseIf cfcfrule5cfrule6 > -1 And cfcfrule5cfrule6 <= -0.8 Then

                    msgconclusiondryrain = "almost certainly not"

                ElseIf cfcfrule5cfrule6 > -0.8 And cfcfrule5cfrule6 <= -0.6 Then

                    msgconclusiondryrain = "probably not"

                ElseIf cfcfrule5cfrule6 > -0.6 And cfcfrule5cfrule6 <= -0.4 Then

                    msgconclusiondryrain = "maybe not"

                ElseIf cfcfrule5cfrule6 > -0.4 And cfcfrule5cfrule6 <= 0.2 Then

                    msgconclusiondryrain = "unknown"

                ElseIf cfcfrule5cfrule6 > 0.2 And cfcfrule5cfrule6 <= 0.4 Then

                    msgconclusiondryrain = "maybe"

                ElseIf cfcfrule5cfrule6 > 0.4 And cfcfrule5cfrule6 <= 0.6 Then

                    msgconclusiondryrain = "probably"

                ElseIf cfcfrule5cfrule6 > 0.6 And cfcfrule5cfrule6 < 1.0 Then


                    msgconclusiondryrain = "almost certain"

                ElseIf cfcfrule5cfrule6 >= 1.0 Then

                    msgconclusiondryrain = "definitely"

                End If

                MsgBox("The probability of having a rain tomorrow is " + msgconclusiondryrain.ToString + "; however we also may expect some dry day!")



                TabControl1.SelectTab(tabforecastmenu)
                My.Computer.Audio.Play(My.Resources.whatmethod, AudioPlayMode.Background)

            End If




        End If



    End Sub

    Private Sub cmbTemp_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbTemp.SelectedIndexChanged

    End Sub

    Private Sub cmbTemp_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbTemp.TextChanged
       


        If rdobcertainty.Checked = True And cmbTemp.Text = "Cold" Then

            ''show lblcold1, lblcold2, cmbnumricTempcold

            lblcold1.Visible = True
            lblcold2.Visible = True
            cmbnumericTempcoldwarm.Visible = True
            lblcold1.Text = "To what degree do you believe the temperature is cold? Enter a numeric certainty "
            lblcold2.Text = "bet. 0 and 1.0 inclusive."



        ElseIf rdobcertainty.Checked = True And cmbTemp.Text = "Warm" Then

            ''show lblcold1, lblcold2, cmbnumricTempcold

            lblcold1.Visible = True
            lblcold2.Visible = True
            cmbnumericTempcoldwarm.Visible = True
            lblcold1.Text = "To what degree do you believe the temperature is warm? Enter a numeric certainty "
            lblcold2.Text = "bet. 0 and 1.0 inclusive."


        Else

            ''hide lblcold1, lblcold2, cmbnumricTempcold

            lblcold1.Visible = False
            lblcold2.Visible = False
            cmbnumericTempcoldwarm.Visible = False


        End If


    End Sub

    Private Sub cmbrainfall_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbrainfall.SelectedIndexChanged

    End Sub

    Private Sub cmbrainfall_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbrainfall.TextChanged


        If rdobcertainty.Checked = True And cmbrainfall.Text = "Low" Then

            ''show lbllow1, lbllow2, cmbnumricrainfalllow

            lbllow1.Visible = True
            lbllow2.Visible = True
            cmbnumericrainfalllow.Visible = True
            lbllow1.Text = "To what degree do you believe the rainfall is low? Enter a numeric certainty "
            lbllow2.Text = "bet. 0 and 1.0 inclusive."

        Else

            ''show lbllow1, lbllow2, cmbnumricrainfalllow

            lbllow1.Visible = False
            lbllow2.Visible = False
            cmbnumericrainfalllow.Visible = False


        End If

    End Sub

    Private Sub cmbSky_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbSky.SelectedIndexChanged

    End Sub

    Private Sub cmbSky_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbSky.TextChanged


        If rdobcertainty.Checked = True And cmbSky.Text = "Overcast" Then

            ''show lblsky, lblsky2, cmbnumericsky

            lblsky1.Visible = True
            lblsky2.Visible = True
            cmbnumericsky.Visible = True
            lblsky1.Text = "To what degree do you believe the sky is overcast? Enter a numeric certainty "
            lblsky2.Text = "bet. 0 and 1.0 inclusive."

        Else

            ''show lblsky, lblsky2, cmbnumericsky

            lblsky1.Visible = False
            lblsky2.Visible = False
            cmbnumericsky.Visible = False

        End If

    End Sub

    Private Sub ForecastAnnouncerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ForecastAnnouncerToolStripMenuItem.Click

    End Sub
End Class
