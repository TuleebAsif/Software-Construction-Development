Please observe copyright and acknowledge the authors.
Original Authors:
Dalimark Tenio-programmer
Maria Angela Pomicpic
Alfredo Densing
John Mark Maquiling
Nikko Bryan Suizo